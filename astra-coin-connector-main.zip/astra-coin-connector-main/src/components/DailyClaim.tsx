
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Clock, Gift } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

interface DailyClaimProps {
  isAuthenticated: boolean;
}

const DailyClaim = ({ isAuthenticated }: DailyClaimProps) => {
  const [lastClaim, setLastClaim] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState<string>('');
  const [canClaim, setCanClaim] = useState(false);

  useEffect(() => {
    // Load last claim time from localStorage
    const storedLastClaim = localStorage.getItem('astra_last_claim');
    
    if (storedLastClaim) {
      setLastClaim(parseInt(storedLastClaim, 10));
    }
  }, []);

  useEffect(() => {
    const calculateTimeLeft = () => {
      if (!lastClaim) {
        setCanClaim(true);
        setTimeLeft('');
        return;
      }

      const now = Date.now();
      const nextClaimTime = lastClaim + 24 * 60 * 60 * 1000; // 24 hours in milliseconds
      
      if (now >= nextClaimTime) {
        setCanClaim(true);
        setTimeLeft('');
      } else {
        setCanClaim(false);
        
        // Calculate remaining time
        const remainingMs = nextClaimTime - now;
        const hours = Math.floor(remainingMs / (1000 * 60 * 60));
        const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((remainingMs % (1000 * 60)) / 1000);
        
        setTimeLeft(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
      }
    };
    
    calculateTimeLeft();
    const intervalId = setInterval(calculateTimeLeft, 1000);
    
    return () => clearInterval(intervalId);
  }, [lastClaim]);

  const handleClaim = () => {
    if (!isAuthenticated) {
      toast.error('Please authenticate with Worldcoin first');
      return;
    }
    
    if (!canClaim) {
      toast.error('You already claimed your daily reward');
      return;
    }
    
    // Store the current time as the last claim time
    const now = Date.now();
    localStorage.setItem('astra_last_claim', now.toString());
    setLastClaim(now);
    setCanClaim(false);
    
    // Get current balance from localStorage, if any
    const currentBalance = localStorage.getItem('astra_balance') || '0';
    const newBalance = (parseFloat(currentBalance) + 5).toString();
    localStorage.setItem('astra_balance', newBalance);
    
    toast.success('Successfully claimed 5 ATC!');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="glassmorphism-card overflow-hidden border-astra-200/50">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center">
            <Gift className="mr-2 h-5 w-5 text-astra-500" />
            Daily Claim
          </CardTitle>
          <CardDescription>
            Claim 5 ATC tokens every 24 hours
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center pb-6">
          <div className="text-center mb-6">
            {canClaim ? (
              <div className="p-4 rounded-full bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400 mx-auto mb-4">
                <Gift className="h-12 w-12" />
              </div>
            ) : (
              <div className="p-4 rounded-full bg-orange-100 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400 mx-auto mb-4">
                <Clock className="h-12 w-12" />
              </div>
            )}
            
            {canClaim ? (
              <p className="text-lg font-medium mb-2">Your daily reward is ready!</p>
            ) : (
              <>
                <p className="text-lg font-medium mb-2">Next reward available in</p>
                <div className="text-2xl font-bold text-gradient mb-2">{timeLeft}</div>
              </>
            )}
          </div>
          
          <Button
            className={`w-full ${canClaim ? 'bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800' : 'bg-gray-300 cursor-not-allowed'} text-white px-6 py-3 rounded-lg font-medium shadow-md transition-all duration-300`}
            onClick={handleClaim}
            disabled={!canClaim || !isAuthenticated}
          >
            {canClaim ? 'Claim 5 ATC' : 'Already Claimed'}
          </Button>
          
          {!isAuthenticated && (
            <p className="text-sm text-red-500 mt-3">Please authenticate with Worldcoin first</p>
          )}
        </CardContent>
        <CardFooter className="border-t border-border bg-background/50 py-3 px-6 text-xs text-foreground/60">
          Earn ATC tokens daily to increase your Astra holdings
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default DailyClaim;
