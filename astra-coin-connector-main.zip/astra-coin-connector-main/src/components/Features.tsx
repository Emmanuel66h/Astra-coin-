
import { useRef } from 'react';
import { useInView } from '@/lib/animations';
import { motion } from 'framer-motion';
import { 
  Shield, 
  Globe, 
  Wallet, 
  Zap, 
  Users,
  Clock
} from 'lucide-react';

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay: number;
}

const Feature = ({ icon, title, description, delay }: FeatureProps) => {
  const [ref, isInView] = useInView<HTMLDivElement>({ threshold: 0.1 });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5, delay: delay * 0.1 }}
      className="glassmorphism-card p-6 sm:p-8 flex flex-col items-start"
    >
      <div className="mb-5 p-3 rounded-xl bg-astra-100 dark:bg-astra-900/20 text-astra-600 dark:text-astra-400">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-foreground/70 text-sm leading-relaxed">{description}</p>
    </motion.div>
  );
};

const Features = () => {
  const [sectionRef, isSectionInView] = useInView<HTMLDivElement>({ threshold: 0.1 });

  const features = [
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Secure Identity",
      description: "Powered by biometric verification for unparalleled account security and protection against fraud."
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: "Global Access",
      description: "Borderless platform accessible from anywhere in the world with an internet connection."
    },
    {
      icon: <Wallet className="h-6 w-6" />,
      title: "Digital Wallet",
      description: "Store, send, and receive Astra Coin with our intuitive and secure wallet system."
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Fast Transactions",
      description: "Lightning-fast transfers with minimal fees, making everyday payments simple."
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Community Governance",
      description: "Participate in platform decisions through our democratic governance model."
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Future Proof",
      description: "Built on cutting-edge technology that evolves with the rapidly changing digital landscape."
    }
  ];

  return (
    <section id="features" className="py-24 px-6 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background to-astra-50/30 to-90% pointer-events-none" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div ref={sectionRef} className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isSectionInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Features</h2>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={isSectionInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <p className="text-foreground/70 max-w-2xl mx-auto">
              Astra Coin combines cutting-edge technology with user-friendly design to create a seamless digital identity and payment platform.
            </p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Feature
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              delay={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
