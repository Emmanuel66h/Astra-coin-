
import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { scrollToElement } from '@/lib/animations';

const Hero = () => {
  const orbitRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const orbitElement = orbitRef.current;
    if (!orbitElement) return;

    const handleMouseMove = (e: MouseEvent) => {
      const { left, top, width, height } = orbitElement.getBoundingClientRect();
      const centerX = left + width / 2;
      const centerY = top + height / 2;
      
      const moveX = (e.clientX - centerX) / 30;
      const moveY = (e.clientY - centerY) / 30;
      
      orbitElement.style.transform = `translate(${moveX}px, ${moveY}px)`;
    };

    document.addEventListener('mousemove', handleMouseMove);
    return () => document.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-6 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-astra-50/30 to-background pointer-events-none" />
      
      {/* Decorative circles */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-astra-100 rounded-full blur-3xl opacity-40 animate-pulse-subtle" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-astra-200 rounded-full blur-3xl opacity-30 animate-pulse-subtle" style={{ animationDelay: '1s' }} />
      
      {/* Moving orbit */}
      <div ref={orbitRef} className="absolute pointer-events-none transition-transform duration-300 ease-out">
        <div className="relative w-[500px] h-[500px] md:w-[800px] md:h-[800px]">
          <div className="absolute top-1/2 left-1/2 w-20 h-20 -ml-10 -mt-10 rounded-full bg-gradient-to-r from-astra-300 to-astra-500 blur-xl opacity-70" />
          
          {[...Array(3)].map((_, i) => (
            <div 
              key={i} 
              className="absolute top-0 left-0 w-full h-full rounded-full border border-astra-200/30"
              style={{ 
                transform: `rotate(${i * 30}deg)`, 
                animationDelay: `${i * 0.5}s` 
              }} 
            />
          ))}
          
          {[...Array(5)].map((_, i) => {
            const size = 4 + i * 2;
            const distance = 150 + i * 70;
            const speed = 15 - i * 2;
            const delay = i * 0.5;
            
            return (
              <motion.div
                key={i}
                className={`absolute top-1/2 left-1/2 w-${size} h-${size} bg-astra-${300 + i * 100} rounded-full`}
                style={{ 
                  width: size, 
                  height: size,
                  x: -size / 2,
                  y: -size / 2,
                }}
                animate={{
                  x: [
                    -size / 2 + distance * Math.cos(0),
                    -size / 2 + distance * Math.cos(Math.PI / 2),
                    -size / 2 + distance * Math.cos(Math.PI),
                    -size / 2 + distance * Math.cos(3 * Math.PI / 2),
                    -size / 2 + distance * Math.cos(2 * Math.PI)
                  ],
                  y: [
                    -size / 2 + distance * Math.sin(0),
                    -size / 2 + distance * Math.sin(Math.PI / 2),
                    -size / 2 + distance * Math.sin(Math.PI),
                    -size / 2 + distance * Math.sin(3 * Math.PI / 2),
                    -size / 2 + distance * Math.sin(2 * Math.PI)
                  ]
                }}
                transition={{
                  repeat: Infinity,
                  duration: speed,
                  ease: "linear",
                  delay
                }}
              />
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6 tracking-tight">
            The Next Generation of <span className="text-gradient">Identity</span> and <span className="text-gradient">Value</span>
          </h1>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <p className="text-lg md:text-xl text-foreground/80 mb-8 md:mb-12 max-w-3xl mx-auto">
            Astra Coin combines secure identity verification with a digital currency system, creating a borderless ecosystem for the future.
          </p>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Button
            size="lg"
            className="bg-gradient-to-r from-astra-500 to-astra-700 hover:from-astra-600 hover:to-astra-800 text-white shadow-lg hover:shadow-xl transition-all duration-300 min-w-[160px]"
            asChild
          >
            <Link to="/dashboard">Get Started</Link>
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            className="border-astra-200 bg-white/80 backdrop-blur-sm hover:bg-white/90 transition-all duration-300 min-w-[160px]"
            asChild
          >
            <Link to="/#about">Learn More</Link>
          </Button>
        </motion.div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-8 left-0 right-0 flex justify-center"
      >
        <button 
          onClick={() => scrollToElement('about')}
          className="flex flex-col items-center text-foreground/60 hover:text-foreground transition-colors"
        >
          <span className="text-sm mb-2">Scroll to learn more</span>
          <ChevronDown className="h-5 w-5 animate-bounce" />
        </button>
      </motion.div>
    </section>
  );
};

export default Hero;
