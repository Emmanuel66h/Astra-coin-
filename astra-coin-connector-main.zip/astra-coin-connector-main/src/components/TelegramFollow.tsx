
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';

const TelegramFollow = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <Card className="glassmorphism-card overflow-hidden border-astra-200/50">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-2 text-blue-500"
            >
              <path d="M21.5 2h-19C1.67 2 1 2.67 1 3.5v17C1 21.33 1.67 22 2.5 22h19c.83 0 1.5-.67 1.5-1.5v-17c0-.83-.67-1.5-1.5-1.5z" />
              <path d="m7 8 5 5 5-5" />
              <path d="M7 12h10" />
              <path d="M7 16h10" />
            </svg>
            Follow Us on Telegram
          </CardTitle>
          <CardDescription>
            Join our Telegram community for updates and support
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center pb-6">
          <div className="text-center mb-6">
            <div className="flex justify-center mb-6">
              <svg 
                width="80" 
                height="80" 
                viewBox="0 0 24 24" 
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
                className="text-blue-500"
              >
                <path 
                  d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" 
                  stroke="currentColor" 
                  strokeWidth="1.5" 
                  fill="rgba(59, 130, 246, 0.1)"
                />
                <path 
                  d="M17.2677 8.56116L15.0023 17.0612C14.9323 17.3312 14.6923 17.5112 14.4123 17.5112C14.3323 17.5112 14.2523 17.4912 14.1723 17.4612L11.1023 16.0312L9.30225 17.8312C9.17225 17.9612 9.01225 18.0312 8.84225 18.0312C8.51225 18.0312 8.24225 17.7612 8.24225 17.4312V15.0912L14.2423 9.09116C14.0623 8.81116 13.6923 8.73116 13.4123 8.91116C11.9723 9.99116 8.65225 12.4612 7.30225 13.4912L4.95225 12.9012C4.55225 12.7912 4.29225 12.3812 4.38225 11.9712C4.44225 11.7212 4.62225 11.5112 4.87225 11.4412L16.4723 7.55116C16.8223 7.42116 17.2023 7.62116 17.3323 7.97116C17.4123 8.17116 17.3723 8.38116 17.2677 8.56116Z"
                  fill="currentColor"
                />
              </svg>
            </div>
            <p className="text-lg mb-4">Stay connected with Astra Coin community</p>
            <p className="mb-6 text-foreground/70">Get the latest updates, announcements, and participate in discussions</p>
          </div>
          
          <Button
            className="w-full bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium shadow-md hover:shadow-lg transition-all duration-300"
            onClick={() => window.open('https://t.me/astracoinclaim', '_blank')}
          >
            <svg 
              className="w-5 h-5 mr-2" 
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path 
                d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" 
                stroke="currentColor" 
                strokeWidth="1.5" 
                fill="rgba(255, 255, 255, 0.1)"
              />
              <path 
                d="M17.2677 8.56116L15.0023 17.0612C14.9323 17.3312 14.6923 17.5112 14.4123 17.5112C14.3323 17.5112 14.2523 17.4912 14.1723 17.4612L11.1023 16.0312L9.30225 17.8312C9.17225 17.9612 9.01225 18.0312 8.84225 18.0312C8.51225 18.0312 8.24225 17.7612 8.24225 17.4312V15.0912L14.2423 9.09116C14.0623 8.81116 13.6923 8.73116 13.4123 8.91116C11.9723 9.99116 8.65225 12.4612 7.30225 13.4912L4.95225 12.9012C4.55225 12.7912 4.29225 12.3812 4.38225 11.9712C4.44225 11.7212 4.62225 11.5112 4.87225 11.4412L16.4723 7.55116C16.8223 7.42116 17.2023 7.62116 17.3323 7.97116C17.4123 8.17116 17.3723 8.38116 17.2677 8.56116Z"
                fill="currentColor"
              />
            </svg>
            Join Telegram Channel
            <ExternalLink className="ml-2 h-4 w-4" />
          </Button>
        </CardContent>
        <CardFooter className="border-t border-border bg-background/50 py-3 px-6 text-xs text-foreground/60">
          https://t.me/astracoinclaim
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default TelegramFollow;
