
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Coins, RefreshCw, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

interface WalletProps {
  isAuthenticated: boolean;
}

const Wallet = ({ isAuthenticated }: WalletProps) => {
  const [balance, setBalance] = useState('0.00');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Load balance from localStorage
    if (isAuthenticated) {
      const storedBalance = localStorage.getItem('astra_balance');
      if (storedBalance) {
        setBalance(storedBalance);
      }
    }
  }, [isAuthenticated]);

  const simulateTransaction = (type: 'send' | 'receive') => {
    if (!isAuthenticated) {
      toast.error('Please authenticate with Worldcoin first');
      return;
    }

    setLoading(true);
    
    setTimeout(() => {
      if (type === 'send') {
        const amount = (parseFloat(balance) - Math.random() * 0.5).toFixed(2);
        setBalance(amount);
        localStorage.setItem('astra_balance', amount);
        toast.success('Transaction sent successfully');
      } else {
        const amount = (parseFloat(balance) + Math.random() * 2).toFixed(2);
        setBalance(amount);
        localStorage.setItem('astra_balance', amount);
        toast.success('Transaction received successfully');
      }
      setLoading(false);
    }, 1500);
  };

  const refreshBalance = () => {
    if (!isAuthenticated) {
      toast.error('Please authenticate with Worldcoin first');
      return;
    }

    setLoading(true);
    
    // Get the balance from localStorage
    setTimeout(() => {
      const storedBalance = localStorage.getItem('astra_balance') || '0.00';
      setBalance(storedBalance);
      toast.success('Balance updated');
      setLoading(false);
    }, 1000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
    >
      <Card className="glassmorphism-card">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center">
            <Coins className="mr-2 h-5 w-5 text-astra-500" />
            Astra Wallet
          </CardTitle>
          <CardDescription>
            Your digital wallet for Astra Coin transactions
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-4">
          <div className="flex flex-col items-center py-6">
            <div className="text-muted-foreground text-sm mb-1">Available Balance</div>
            <div className="text-4xl font-bold text-gradient mb-4">{balance} ATC</div>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-1"
              onClick={refreshBalance}
              disabled={loading}
            >
              <RefreshCw className={`h-3 w-3 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            <Button 
              className="bg-gradient-to-r from-green-500 to-green-700 hover:from-green-600 hover:to-green-800 text-white shadow-md"
              onClick={() => simulateTransaction('receive')}
              disabled={loading || !isAuthenticated}
            >
              <ArrowDownLeft className="mr-2 h-4 w-4" />
              Receive
            </Button>
            <Button 
              className="bg-gradient-to-r from-astra-500 to-astra-700 hover:from-astra-600 hover:to-astra-800 text-white shadow-md"
              onClick={() => simulateTransaction('send')}
              disabled={loading || !isAuthenticated}
            >
              <ArrowUpRight className="mr-2 h-4 w-4" />
              Send
            </Button>
          </div>
        </CardContent>
        <CardFooter className="text-xs text-muted-foreground pt-0">
          {isAuthenticated 
            ? "Your wallet is connected and secure" 
            : "Please authenticate with Worldcoin to access your wallet"}
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default Wallet;
