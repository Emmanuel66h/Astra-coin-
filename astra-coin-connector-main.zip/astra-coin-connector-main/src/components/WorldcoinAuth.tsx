
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { IDKitWidget, ISuccessResult } from '@worldcoin/idkit';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

interface WorldcoinAuthProps {
  onAuthStatusChange: (status: boolean) => void;
}

const WorldcoinAuth = ({ onAuthStatusChange }: WorldcoinAuthProps) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if user was previously authenticated
    const storedAuth = localStorage.getItem('worldcoin_authenticated');
    if (storedAuth === 'true') {
      setIsAuthenticated(true);
      onAuthStatusChange(true);
    }
  }, [onAuthStatusChange]);

  const handleVerify = (result: ISuccessResult) => {
    console.log("WorldID verification successful:", result);
    setIsAuthenticated(true);
    localStorage.setItem('worldcoin_authenticated', 'true');
    onAuthStatusChange(true);
    toast.success("Successfully verified with Worldcoin!");
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('worldcoin_authenticated');
    onAuthStatusChange(false);
    toast.info("Logged out successfully");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="glassmorphism-card overflow-hidden border-astra-200/50">
        <CardHeader className="pb-4">
          <CardTitle>Worldcoin Authentication</CardTitle>
          <CardDescription>
            {isAuthenticated ? 
              "You're authenticated with Worldcoin" : 
              "Verify your identity with Worldcoin to access your Astra wallet"}
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center pb-6">
          {!isAuthenticated ? (
            <div className="flex flex-col items-center">
              <img 
                src="https://assets.onecompiler.app/42p32vw56/43bcqbgx8/1000012334.png" 
                alt="Worldcoin Logo" 
                className="w-24 h-24 mb-6" 
              />
              <IDKitWidget
                app_id="app_2cc26994d77eadd3f7f0952a746d38f7" 
                action="astra-x"
                onSuccess={handleVerify}
                handleVerify={(verificationResponse) => {
                  console.log(verificationResponse);
                  // Return void instead of boolean to match the expected type
                  return Promise.resolve();
                }}
              >
                {({ open }) => (
                  <button 
                    onClick={open}
                    className="bg-gradient-to-r from-astra-500 to-astra-700 hover:from-astra-600 hover:to-astra-800 text-white px-6 py-3 rounded-lg font-medium shadow-md hover:shadow-lg transition-all duration-300"
                  >
                    Verify with Worldcoin
                  </button>
                )}
              </IDKitWidget>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-4">
              <div className="bg-astra-100 dark:bg-astra-900/20 text-astra-600 dark:text-astra-400 p-4 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                  <polyline points="22 4 12 14.01 9 11.01"></polyline>
                </svg>
              </div>
              <p className="text-lg font-medium text-center">Successfully Authenticated</p>
              <p className="text-foreground/70 text-center mb-4">Your Astra wallet is now active</p>
              <button 
                onClick={handleLogout}
                className="text-foreground/70 hover:text-foreground underline text-sm transition-colors"
              >
                Sign out
              </button>
            </div>
          )}
        </CardContent>
        <CardFooter className="border-t border-border bg-background/50 py-3 px-6 text-xs text-foreground/60">
          Worldcoin provides secure, privacy-preserving identity verification
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default WorldcoinAuth;
