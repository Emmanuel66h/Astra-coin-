
import { useEffect, useState, useRef, RefObject } from 'react';

// Hook to detect when an element is in the viewport for animations
export function useInView<T extends HTMLElement = HTMLElement>(options?: IntersectionObserverInit): [RefObject<T>, boolean] {
  const ref = useRef<T>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      setIsInView(entry.isIntersecting);
    }, { threshold: 0.1, ...options });

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [options]);

  return [ref, isInView];
}

// Hook to delay the appearance of elements in a sequence
export function useSequence(delay: number = 100, initialDelay: number = 0): (index: number) => { style: { opacity: number; transform: string; transition: string } } {
  return (index: number) => {
    const itemDelay = initialDelay + index * delay;
    
    return {
      style: {
        opacity: 0,
        transform: 'translateY(20px)',
        transition: `opacity 0.5s ease ${itemDelay}ms, transform 0.5s ease ${itemDelay}ms`,
      }
    };
  };
}

// Hook to smoothly transition between pages
export function usePageTransition(): { opacity: number; transform: string } {
  const [style, setStyle] = useState({ opacity: 0, transform: 'translateY(10px)' });

  useEffect(() => {
    const timeout = setTimeout(() => {
      setStyle({ opacity: 1, transform: 'translateY(0px)' });
    }, 50);
    
    return () => clearTimeout(timeout);
  }, []);

  return style;
}

// Smooth scrolling to element
export function scrollToElement(elementId: string): void {
  const element = document.getElementById(elementId);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
