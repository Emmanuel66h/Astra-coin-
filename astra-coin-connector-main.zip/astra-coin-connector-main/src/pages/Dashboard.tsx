
import { useState, useEffect } from 'react';
import { usePageTransition } from '@/lib/animations';
import WorldcoinAuth from '@/components/WorldcoinAuth';
import Wallet from '@/components/Wallet';
import DailyClaim from '@/components/DailyClaim';
import TelegramFollow from '@/components/TelegramFollow';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Coins, Gift, ExternalLink } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const Dashboard = () => {
  const style = usePageTransition();
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    // Check if user was previously authenticated
    return localStorage.getItem('worldcoin_authenticated') === 'true';
  });

  const handleAuthStatusChange = (status: boolean) => {
    setIsAuthenticated(status);
  };

  useEffect(() => {
    // Update wallet balance from localStorage when authentication changes
    if (isAuthenticated) {
      // Make sure there's a balance in localStorage when authenticated
      if (!localStorage.getItem('astra_balance')) {
        localStorage.setItem('astra_balance', '0.00');
      }
    }
  }, [isAuthenticated]);

  return (
    <div
      style={{
        opacity: style.opacity,
        transform: style.transform,
        transition: 'opacity 0.5s ease, transform 0.5s ease',
      }}
    >
      <div className="py-12 px-6">
        <Button
          variant="outline"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="mr-2" />
          Back
        </Button>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-xl mx-auto text-center mb-8"
        >
          <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
          <p className="text-foreground/70">
            {isAuthenticated
              ? "You're authenticated with Worldcoin. Your wallet is now active."
              : "To access your Astra wallet, please authenticate with Worldcoin."}
          </p>
        </motion.div>
        
        <Tabs defaultValue="wallet" className="max-w-5xl mx-auto">
          <TabsList className="grid grid-cols-4 mb-8">
            <TabsTrigger value="wallet" className="flex items-center gap-2">
              <Coins className="h-4 w-4" />
              <span className="hidden sm:inline">Wallet</span>
            </TabsTrigger>
            <TabsTrigger value="auth" className="flex items-center gap-2">
              <svg 
                width="16" 
                height="16" 
                viewBox="0 0 24 24" 
                fill="none" 
                xmlns="http://www.w3.org/2000/svg"
                className="text-current"
              >
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
                <path d="M12 6V18" stroke="currentColor" strokeWidth="2" />
                <path d="M6 12H18" stroke="currentColor" strokeWidth="2" />
              </svg>
              <span className="hidden sm:inline">Authenticate</span>
            </TabsTrigger>
            <TabsTrigger value="claim" className="flex items-center gap-2">
              <Gift className="h-4 w-4" />
              <span className="hidden sm:inline">Daily Claim</span>
            </TabsTrigger>
            <TabsTrigger value="social" className="flex items-center gap-2">
              <ExternalLink className="h-4 w-4" />
              <span className="hidden sm:inline">Follow Us</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="wallet">
            <div className="grid md:grid-cols-1 gap-8">
              <Wallet isAuthenticated={isAuthenticated} />
            </div>
          </TabsContent>
          
          <TabsContent value="auth">
            <div className="grid md:grid-cols-1 gap-8">
              <WorldcoinAuth onAuthStatusChange={handleAuthStatusChange} />
            </div>
          </TabsContent>
          
          <TabsContent value="claim">
            <div className="grid md:grid-cols-1 gap-8">
              <DailyClaim isAuthenticated={isAuthenticated} />
            </div>
          </TabsContent>
          
          <TabsContent value="social">
            <div className="grid md:grid-cols-1 gap-8">
              <TelegramFollow />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Dashboard;
