
import { useEffect } from 'react';
import { usePageTransition } from '@/lib/animations';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Features from '@/components/Features';

const Index = () => {
  const style = usePageTransition();
  
  useEffect(() => {
    // Add animation observer for scroll animations
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in-view');
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.animate-on-scroll').forEach((element) => {
      observer.observe(element);
    });

    return () => {
      document.querySelectorAll('.animate-on-scroll').forEach((element) => {
        observer.unobserve(element);
      });
    };
  }, []);

  return (
    <div 
      style={{ 
        opacity: style.opacity, 
        transform: style.transform, 
        transition: 'opacity 0.5s ease, transform 0.5s ease' 
      }}
    >
      <Navbar />
      <main>
        <Hero />
        
        <div id="about" className="py-24 px-6 relative">
          <div className="max-w-5xl mx-auto">
            <div className="mb-12 text-center animate-on-scroll">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">About Astra Coin</h2>
              <p className="text-lg text-foreground/80 max-w-3xl mx-auto">
                Astra Coin is at the forefront of building a more equitable digital economy. By combining secure identity verification with a digital currency system, we're creating a future where everyone has equal access to financial opportunities.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="animate-on-scroll">
                <h3 className="text-xl font-semibold mb-4">Our Vision</h3>
                <p className="text-foreground/70 mb-6">
                  We envision a world where digital identity and digital currency work together seamlessly, providing everyone with secure access to the global economy regardless of their background or location.
                </p>
                <p className="text-foreground/70">
                  By leveraging cutting-edge biometric technology, we ensure that every account represents a unique human being, preventing fraud and creating a level playing field for all participants.
                </p>
              </div>
              
              <div className="animate-on-scroll" style={{ transitionDelay: '0.2s' }}>
                <h3 className="text-xl font-semibold mb-4">How It Works</h3>
                <p className="text-foreground/70 mb-6">
                  Astra Coin uses Worldcoin's secure identity verification system to establish your unique digital identity. Once verified, you gain access to your Astra Coin wallet, where you can send and receive funds globally with minimal fees.
                </p>
                <p className="text-foreground/70">
                  Our platform is designed to be intuitive and user-friendly, making digital currency accessible to everyone, regardless of technical expertise.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <Features />
        
        <div className="py-24 px-6 bg-astra-50/30 relative">
          <div className="max-w-5xl mx-auto text-center">
            <div className="mb-12 animate-on-scroll">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
              <p className="text-lg text-foreground/80 max-w-3xl mx-auto">
                Join the next generation of identity-verified digital currency users and take control of your financial future.
              </p>
            </div>
            
            <div className="animate-on-scroll">
              <a 
                href="/dashboard" 
                className="inline-block px-8 py-4 bg-gradient-to-r from-astra-500 to-astra-700 hover:from-astra-600 hover:to-astra-800 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Get Started with Astra Coin
              </a>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="py-12 px-6 bg-gradient-to-b from-background to-astra-50/20">
        <div className="max-w-5xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-astra-400 to-astra-700 flex items-center justify-center">
              <span className="text-white font-bold text-sm">A</span>
            </div>
            <span className="font-semibold text-lg">Astra Coin</span>
          </div>
          
          <p className="text-sm text-foreground/60">
            &copy; {new Date().getFullYear()} Astra Coin. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
